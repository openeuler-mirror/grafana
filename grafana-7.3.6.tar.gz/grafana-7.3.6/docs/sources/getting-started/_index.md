+++
title = "Getting started"
type = "docs"
[menu.docs]
name = "Getting started"
identifier = "getting-started"
weight = 100
+++

# Getting started

These guides will help beginners get started and acquainted with Grafana. To learn more about Grafana in general, refer to [What is Grafana?]({{< relref "what-is-grafana.md" >}}).
