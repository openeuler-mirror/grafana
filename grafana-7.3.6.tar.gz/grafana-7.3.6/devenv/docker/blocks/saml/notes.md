# Notes on Saml Docker Block

Uses https://github.com/kristophjunge/docker-test-saml-idp as a docker container for saml example.

## Use

See docker container docs on how to use this service - https://github.com/kristophjunge/docker-test-saml-idp#test-the-identity-provider-idp

## Groups & Users

admins
  saml-admin (saml-admin@grafana.com)
editors
  saml-editor (saml-editor@grafana.com)
no groups
  saml-viewer (saml-viewer@grafana.com)
