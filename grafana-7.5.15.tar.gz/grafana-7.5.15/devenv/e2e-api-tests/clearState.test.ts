import * as setup from './setup';

describe.skip('clear state', () => {
  it('will clear state', () => {
    return setup.clearState();
  });
});
